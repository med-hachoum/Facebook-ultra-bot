# -*- coding: utf-8 -*-

from selenium import webdriver
from random import randint
import itertools
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import time
import bag_of_variables
print('---------------------------------')

print('Facebook ultra bot with PhantomJs')
print('By Med hachoum .')

print('---------------------------------')

try:
    driver = webdriver.PhantomJS(executable_path=bag_of_variables.phantomj_spath)
    #driver = webdriver.Firefox()
except:
    print('''
    Error while loading libraries: PhantomJs.exe
    ----> Add PhantomJs.exe to the application folder
    ... And restart the Bot .
    ''')
    time.sleep(5000)

driver.implicitly_wait(30)
try:
    driver.get("https://m.facebook.com/")
except:
    print('No Internet Connection !')
driver.find_element_by_name("email").clear()
driver.find_element_by_name("email").send_keys(bag_of_variables.user)
driver.find_element_by_name("pass").clear()
driver.find_element_by_name("pass").send_keys(bag_of_variables.password)
driver.find_element_by_name("login").click()

print('Facebook : Wait for login ...')

time.sleep(2)

s = driver.current_url
if 'login/?email' not in s:
    print('''
    ------------------------------
    Facebook :Successful login .
    ------------------------------
    ''')

else:
    print('''
    Facebook :invalid login credentials !
    ---->  Add a valid facebook user and password to Config.ini file (locate in config folder)
    ''')
    time.sleep(120)
    exit()

try:
    with open(bag_of_variables.count_friends, "r") as count:
        resume = (count.read())
except:

    countfile = open(bag_of_variables.count_friends, "w")
    countfile.write(str('0'))
    countfile.close()

with open(bag_of_variables.friend_to_add, "r") as text_file:
    for index, line in enumerate(itertools.islice(text_file, int(resume), None)):
        driver.get(line)
        resume = (int(resume) + int(1))
        print('-------------------------------------------------')
        print(('Sending Friend request to the number %d ..') % (resume))

        fburl = open(bag_of_variables.count_friends, "w")
        fburl.write(str(resume))
        fburl.close()



        ##  if len(driver.find_elements_by_css_selector("html#facebook.sidebarMode.tinyViewport.tinyHeight body._4lh.timelineLayout.noFooter.fbx._3na7._5p3y.gecko.win.x1.Locale_en_US div._li div#globalContainer.uiContextualLayerParent div#content.fb_content.clearfix div div#mainContainer div#contentCol.clearfix.hasRightCol div#contentArea div#pagelet_timeline_main_column._5h60 div#timeline_top_section._5h60 div.fbTimelineTopSectionBase._6-d div.fbTimelineSection.mtm.fbTimelineTopSection div#fbProfileCover div#fbTimelineHeadline.clearfix div._50zj div.actions._70j div#pagelet_timeline_profile_actions._5h60.actionsDropdown div#u_jsonp_4_a._2yfv._2yfv.FriendButton button._42ft._4jy0.FriendRequestAdd.addButton._4jy4._517h._9c6")) > 0:
        try:
            driver.find_element_by_link_text("Add Friend").click()
            print(('Friend request has been sent to: %s ') % (line))
            wait_adds= randint(bag_of_variables.random_time_min, bag_of_variables.random_time_max)
            print (('Random Wait : %s seconds ..')%(wait_adds))
            time.sleep(wait_adds)


        except:
            print (('Friend request Failed on :%s , Go to the next (%d)')% (line , resume+1))
            time.sleep(5)

        for i in range(15):
            try:
                driver.get("https://m.facebook.com/")
                driver.find_element_by_link_text("Like").click()
                Liketime = (randint(bag_of_variables.random_wait_time_likes_min, bag_of_variables.random_wait_time_likes_max))
                print (('Random Wait For The Next Like : %s seconds ..')%(Liketime))

                time.sleep(Liketime)
                print(('facebook :%d/15 post liked ') % (i+1))
            except:

                Liketime = (randint(bag_of_variables.random_time_min, bag_of_variables.random_time_max))
                print('Status Like Failed , go to the next statu !')
                print (('Random Wait : %s seconds ..')%(Liketime))
                time.sleep(Liketime)



    time.sleep((randint(bag_of_variables.random_time_min, bag_of_variables.random_time_max)))
    exit()




