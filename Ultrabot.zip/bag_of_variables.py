#!/usr/bin/python
# -*- coding: utf-8 -*-
import configparser

import os
# config files path
configs =os.path.join(os.getcwd(), "configs\\")
config_file =os.path.join(os.getcwd(), "configs\config.ini")
phantomj_spath =os.path.join(os.getcwd(), "configs\phantomjs.exe")

# config.ini file
config = configparser.ConfigParser()
config.read(config_file)

password = config.get('login', 'pass')
user = config.get('login', 'user')

random_time_min =int(config.get('random_wait_time', 'min'))
random_time_max = int(config.get('random_wait_time', 'max'))

random_wait_time_likes_min = int(config.get('random_wait_time_likes', 'min'))
random_wait_time_likes_max = int(config.get('random_wait_time_likes', 'max'))


friend_to_add= ( os.path.join(configs,str(config.get('files', 'friend_to_add'))))
count_friends = ( os.path.join(configs,str(config.get('files', 'start_add_friends_from'))))
start_posts_from = ( os.path.join(configs,str(config.get('files', 'start_posts_from'))))
posts = ( os.path.join(configs,str(config.get('files', 'posts'))))


# Print Configs
#print (('friends file is: %s')% (friend_to_add))
#print (('friends count file is :%s')% (count_friends))
#print (('Random time: min =%s , max =%s')% (random_time_min,random_time_max))
